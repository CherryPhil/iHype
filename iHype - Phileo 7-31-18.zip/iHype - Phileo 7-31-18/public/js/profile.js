// Sub Tab
function switchDisplay(str) {
    $(".myProfileCont").css("display", "none");
    $(".myPersonalInformationCont").css("display", "none");
    $(".myListingsCont").css("display", "none");
    $(".myFavoritesCont").css("display", "none");
    $(".myFavoritesCont").css("display", "none");
    $(".myReviewsCont").css("display", "none");
    $(".myTransactionsCont").css("display", "none");
    $("."+str).css("display", "block");
}

function changeTabStyle(pressed) {
    $("#profileTab").css("background-color", "#d8d8d8");
    $("#personalTab").css("background-color", "#d8d8d8");
    $("#listingsTab").css("background-color", "#d8d8d8");
    $("#favoritesTab").css("background-color", "#d8d8d8");
    $("#reviewsTab").css("background-color", "#d8d8d8");
    $("#transactionsTab").css("background-color", "#d8d8d8");
    var idName = pressed.id;
    $("#"+idName).css("background-color", "white");
}

$(".subTabList").on("click", function(){
    var str = this.innerHTML;
    str = "my" + str.split(" ").join("") + "Cont"
    if ($("."+str).css("display") != "block"){
        switchDisplay(str);
        changeTabStyle(this);
        profileCancel(1);
        profileCancel(2);

        // For the Edit & Update button
        $(".disabled").attr("disabled", "disabled");
        $("#editProfileButton").css("display", "block");
        $("#cancelProfileButton").css("display", "none");
        $("#updateProfileButton").css("display", "none");
        $("#editPriProfileButton").css("display", "block");
        $("#cancelPriProfileButton").css("display", "none");
        $("#updatePriProfileButton").css("display", "none");
    }
})

// Profile Edit Button
$("#editProfileButton").on("click", function(){
    $("#editProfileButton").css("display", "none");
    $("#cancelProfileButton").css("display", "inline-block");
    $("#updateProfileButton").css("display", "inline-block");
    $(".disabled").removeAttr("disabled");
    $("#profileFirst").focus()
    [0].setSelectionRange(-1, -1);
})

// Private Profile Edit Button
$("#editPriProfileButton").on("click", function(){
    $("#editPriProfileButton").css("display", "none");
    $("#cancelPriProfileButton").css("display", "inline-block");
    $("#updatePriProfileButton").css("display", "inline-block");
    $(".disabled").removeAttr("disabled");
    // $("#profileEmail").focus();
})

// Open change Username Modal
$("#changeUsernameButton").on("click", function(){
    $("#newUsername").val("");
    $("#currentPasswordInput2").val("");
    $("#modalChangeUsernameButton").attr("disabled", "disabled")
    .attr("class", "btn btn-default modalButtons");
})

// Open change Password Modal
$("#changePasswordButton").on("click", function(){
    $(".passwordInputs").val("");
    $("#changePassError").val("")
    .css("display", "none");
    $("#modalChangePasswordButton").attr("disabled", "disabled")
    .attr("class", "btn btn-default modalButtons");
})

// Check if new password = confirm new password
function buttonActivate() {
    if ($("#newPasswordInput").val() == "" || $("#currentPasswordInput").val() == ""){
        buttonDeactivate(0);
    } else {
        $("#modalChangePasswordButton").removeAttr("disabled");
        $("#modalChangePasswordButton").attr("class", "btn btn-default modalButtonsAct");
    }
}
function buttonDeactivate(num) {
    if (num == 1) {
        $("#changePassError").html("<span class='fa fa-warning'></span>&nbsp;&nbsp;Passwords do not match.")
        .css("display", "block");
    } else if (num == 2) {
        if ($("#currentPasswordInput").val() != ""){
            $("#changePassError").html("<span class='fa fa-warning'></span>&nbsp;&nbsp;New password must not be the same as current password.")
            .css("display", "block");
        }
    }
    $("#modalChangePasswordButton").attr("disabled", "disabled")
    .attr("class", "btn btn-default modalButtons");
}
function checkPass() {
    $("#changePassError").val("")
    .css("display", "none");
    if ($("#newPasswordInput").val() == $("#confNewPasswordInput").val()){
        if ($("#newPasswordInput").val() != $("#currentPasswordInput").val()) {
            buttonActivate();
        } else {
            buttonDeactivate(2);
        }
    } else {
        buttonDeactivate(1);
    }
}

// Check for Changing Username
function checkForNoVal(){
    if ($("#newUsername").val() != "" && $("#currentPasswordInput2").val() != ""){
        $("#modalChangeUsernameButton").removeAttr("disabled")
        .attr("class", "btn btn-default modalButtonsAct");
    } else {
        $("#modalChangeUsernameButton").attr("disabled", "disabled")
        .attr("class", "btn btn-default modalButtons");
    }
}

// Confirm Update???
function confirmationMsg() {
    return confirm("Confirm update?");
}

// Move to Favorite
function clickFav() {
    $("#favoritesTab").click();
}

// View Overlay to Change Avatar
$("#changeImageButton").on("click", function(){
    $("#overlay").css("display", "block");
    $("#updateAvatarButton").css("display", "none");
    $("#uploadImg").val("");
    cropForOverlayProfileImage(2);
})
$("#overlayX").click(function(){
    $("#overlay").css("display", "none");
})

// Cropping
function cropForOverlayProfileImage(num){
    if(num == 1) {
        var image = document.getElementById("overlayDummieImg");
    } else if (num == 2) {
        var image = document.getElementById("dummieImg");
    }
    var canvas = document.getElementById("overlayProfileImg");
    var ctx = canvas.getContext("2d");
    var width = image.naturalWidth;
    var height = image.naturalHeight;

    if (height == width) {
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    } else {
        var diff = width - height;
        var absPaddingDiff = Math.abs(diff) / 2;
        if (diff < 0) {
            ctx.drawImage(image, 0, absPaddingDiff, width, height-absPaddingDiff*2, 0, 0, canvas.width, canvas.height);
        } else {
            ctx.drawImage(image, absPaddingDiff, 0, width-absPaddingDiff*2, height, 0, 0, canvas.width, canvas.height);
        }
    }
}

// Crop with Canvas
$("#overlayDummieImg").on("load", function(){
    cropForOverlayProfileImage(1);
    $("#updateAvatarButton").css("display", "inline-block");
})

// Update pic in Circle
function openFile(event) {
    var input = event.target;
    var reader = new FileReader();
    reader.onload = function(){
        var dataURL = reader.result;
        $("#overlayDummieImg").attr("src", dataURL);
    }
    reader.readAsDataURL(input.files[0]);
}