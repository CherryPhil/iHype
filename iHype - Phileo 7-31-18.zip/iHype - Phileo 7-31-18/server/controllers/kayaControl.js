var ReportModel = require('../models/reportModel');
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

//List Reports
exports.list = function (req, res) {
    if(req.session.username == undefined){
        res.redirect("/login");
    } else {
        ReportModel.findAll({where: {
            username: req.session.username
        }}).then(function(reportData){
            res.render("report", {
                title: "Reports Page",
                reports: reportData,
                username: req.session.username,
                picture: req.session.picture
            })
        })
    }
}

//Create the reports
exports.create = function (req, res) {
    console.log("Creating Reports")

    var newReport = {
        report_title: req.body.reporttitle,
        report_content: req.body.reportcontent,
        username: req.session.username
    }
    ReportModel.create(newReport).then(function(){
        res.redirect('/report');
    });
};

//delete report
exports.delete = function (req,res) {
    var record_num = req.params.reports_id;
    console.log("deleting report " + record_num);
    ReportModel.destroy({where: {id: record_num}}).then((deletedReport)=>{
        if(!deletedReport){
            return res.send(400, {
                message: "Error"
            });
        }

        res.status(200).send({ message: "Deleted Report: " + record_num});
    })
}


exports.openCustomerCare = function(req, res) {
    res.render("CustomerCare", {
        title: "Customer Care",
        username: req.session.username,
        picture: req.session.picture
    })
}

exports.openFAQ = function(req, res) {
    res.render("FAQ", {
        title: "FAQ",
        username: req.session.username,
        picture: req.session.picture
    })
}

exports.openhelpcenter = function(req, res) {
    res.render("help_center", {
        title: "Help Center",
        username: req.session.username,
        picture: req.session.picture
    })
}