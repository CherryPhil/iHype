var express = require("express");
var session = require("express-session");
var app = express();
var bodyParser = require("body-parser");
var path = require("path");
var socket = require("socket.io");

// Multer
var multer = require("multer");
var upload = multer({ dest: "./public/uploads/", limits: {fileSize: 1500000000, files: 1} })

app.set('views', path.join(__dirname, 'server/views'));
app.set('view engine', 'ejs');

app.use(session({ secret: "helloiHype" }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/public', express.static(path.join(__dirname, 'public')))

var server = app.listen(3000);

// SUGI
    // All
var sugi = require("./server/controllers/sugiControl");
app.get("/terms&conditions", sugi.openTermsConditions);
app.get("/privacy", sugi.openPrivacy);
app.get("/login", sugi.openLogin);
app.get("/logout", sugi.logout);
app.get("/", sugi.openHome);
    // After Login
app.get("/profile", sugi.openProfile);
app.get("/openFav", sugi.openFavorite);
    // Forms
app.post("/login", sugi.login);
app.post("/adminLogin", sugi.adminLogin);
app.post("/register", sugi.register);
app.post("/updateUsername", sugi.updateUsername);
app.post("/updateProfile", sugi.updateProfile);
// app.post("/updatePrivateProfile", sugi.updatePrivateProfile);
app.post("/updatePassword", sugi.updatePassword);
app.post("/updateAvatar", upload.single("uploadImg"), sugi.updateAvatar);
    // AJAX
app.post("/checkSimilarUsername", sugi.checkSimilarUsername);

// PHILEO
var phil = require("./server/controllers/philControl");
app.get("/sell", phil.openSell);
app.get("/categories/:username/:name", phil.openDisplay);

app.post("/categories", upload.single("listingIMG1"), phil.uploadSell);
app.post("/checkSimilarTitle", phil.checkTitle);
app.post("/upFav", phil.increaseFav);
app.post("/downFav", phil.decreaseFav);
app.post("/postComment", phil.postComment);

// SHUAN JIN
var jin = require("./server/controllers/jinControl");
var MsgModel = require("./server/models/msgModel");
var io = socket(server);


io.on("connection", function(socket){
    console.log("made socket connection", socket.id);

    socket.on("chat", function(data){
       io.sockets.emit("chat", data);
    });
    
    socket.on("typing", function(data){
        socket.broadcast.emit("typing", data);
    });
});

app.get("/chat", jin.myChat);

app.post("/chat", jin.UploadOffer);

// ERNEST
var productsController = require("./server/controllers/productsController")
app.get("/categories", productsController.list);
app.get("/categories/popular", productsController.listPopular);
app.get("/categories/hightolow", productsController.listHighLow);
app.get("/categories/lowtohigh", productsController.listLowHigh);

// KAI YANG
var kaya = require("./server/controllers/kayaControl");
app.get("/report", kaya.list);
app.get("/CustomerCare", kaya.openCustomerCare);
app.get("/FAQ", kaya.openFAQ);
app.get("/help_center", kaya.openhelpcenter);

app.post("/report", kaya.create);

app.delete("/report", kaya.delete);

app.get('*',function (req, res) {
    res.redirect('/');
});