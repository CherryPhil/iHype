var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const ReportModel = sequelizeInstance.define('reports', {
    report_id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    report_title: {
        type: Sequelize.STRING,
        allowNull: false
    },
    report_content: {
        type: Sequelize.STRING,
        allowNull: false
    },
    username: {
        type: Sequelize.STRING,
        allowNull: false
    }
});

ReportModel.sync({ force: false });

module.exports = sequelizeInstance.model('reports', ReportModel);