var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const offerModel = sequelizeInstance.define("offers", {
    method: {
        type: Sequelize.STRING
    },
    meetup_Date: {
        type: Sequelize.STRING
    },
    meetup_Time: {
        type: Sequelize.STRING
    },
    meetup_location: {
        type: Sequelize.STRING
    },
    meetup_price: {
        type: Sequelize.FLOAT
    },
    delivery_date: {
        type: Sequelize.STRING
    },
    delivery_address: {
        type: Sequelize.STRING
    },
    delivery_price: {
        type: Sequelize.FLOAT
    },
});

offerModel.sync({ force: false });

module.exports = sequelizeInstance.model('offers', offerModel);