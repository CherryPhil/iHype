var fs = require('fs');

var UserModel = require('../models/usersModel');
var AdminModel = require('../models/adminModel');
var ListingModel = require('../models/listingModel');

var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

// Login Page
exports.openLogin = function(req, res) {
    if(req.session.username || req.session.adminUsername){
        res.redirect("/");
    } else {
        res.render("login", {
            title: "Login",
            error: "",
            regError: "",
            adminError: ""
        })
    }
}

// Logging In
exports.login = function(req, res) {
    var Username = req.body.logUsername;
    var Pass = req.body.logPass;
    UserModel.findAll({
        where: {
            username: Username
        }
    }).then(function(person) {
        if(person[0].password == Pass){
            req.session.username = req.body.logUsername;
            req.session.picture = person[0].profileimg;
            res.redirect("/");
        } else {
            res.render("login", {
                title: "Login",
                error: "Incorrect password!",
                regError: "",
                adminError: ""
            })
        }
    }).catch(function() {
        res.render("login", {
            title: "Login",
            error: "This username does not exist!",
            regError: "",
            adminError: ""
        })
    })
}

// Admin Loggin In
exports.adminLogin = function(req, res) {
    var Username = req.body.adminUsername;
    var Pass = req.body.adminPass;
    AdminModel.findAll({
        where: {
            username: Username
        }
    }).then(function(admin) {
        if(admin[0].password == Pass){
            req.session.adminUsername = req.body.adminUsername;
            res.redirect("/");
        } else {
            res.render("login", {
                title: "Login",
                error: "",
                regError: "",
                adminError: "Incorrect password!"
            })
        }
    }).catch(function() {
        res.render("login", {
            title: "Login",
            error: "",
            regError: "",
            adminError: "This admin username does not exist!"
        })
    })
}

// Logging Out
exports.logout = function(req, res) {
    req.session.destroy(function(){
        res.redirect("/login");
    })
}

// Registering
exports.register = function(req, res) {

    var newUser = {
        username: req.body.regUsername,
        email: req.body.regEmail,
        password: req.body.regConPass,
        profileimg: "defaultImg.jpg",
        favorites: JSON.stringify([])
    }
    
    UserModel.findAll({
        where: {
            email: req.body.regEmail
        }
    }).then(function(existUsername){
        if(existUsername[0].email){
            res.render("login", {
                title: "Login",
                error: "",
                regError: "This email is already in use!",
                adminError: ""
           })
        }
    }).catch(function(){
        if(req.body.regPass != req.body.regConPass){
            res.render("login", {
                title: "Login",
                error: "",
                regError: "Passwords do not match!",
                adminError: ""
            })
        } else {
            UserModel.create(newUser).then(function(newUser){
                req.session.username = req.body.regUsername;
                req.session.picture = newUser.profileimg;
                res.redirect("/");
            }).catch(function(){
                res.render("login", {
                    title: "Login",
                    error: "",
                    regError: "Username already taken!",
                    adminError: ""
                })
            })
        }
    })
}

// Home Page
exports.openHome = function(req, res) {
    res.render("home", {
        title: "Home",
        username: req.session.username,
        picture: req.session.picture,
        adminUsername: req.session.adminUsername
    })
}

// Profile Page
exports.openProfile = function(req, res) {
    UserModel.findAll({
        where: {
            username: req.session.username
        }
    }).then(function(retrievedData){
        if(req.session.admin){
            res.redirect("/");
        }
        if(retrievedData[0] == undefined){
            res.redirect("/login");
        } else {
            var favDict = JSON.parse(retrievedData[0].favorites);
            var fav = req.session.openFav
            req.session.openFav = undefined;
            res.render("profile", {
                title: "Profile",
                username: req.session.username,
                userData: retrievedData[0],
                goFav: fav,
                allFavorites: favDict,
                picture: req.session.picture
            })
        }
    })
}

// Profile Page Favorite Tab
exports.openFavorite = function(req, res) {
    req.session.openFav = "Favorite!";
    res.redirect("/profile");
}

// Update Username
exports.updateUsername = function(req, res) {
    var updateData = {
        username: req.body.username
    }
    UserModel.update(updateData, { where: {
        username: req.session.username
    }}).then(function(){
        req.session.username = updateData.username;
        res.redirect("/profile");
    })
}

// Update Profile
exports.updateProfile = function(req, res) {
    if(req.body.profileMobile == ""){
        var mobileNum = null;
    } else {
        var mobileNum = req.body.profileMobile;
    }
    var updateData = {
        firstname: req.body.profileFirst,
        lastname: req.body.profileLast,
        mobile: mobileNum,
        bio: req.body.profileBio
    }
    UserModel.update(updateData, { where: {
        username: req.session.username
    }}).then(function(){
        res.redirect("/profile");
    })
}

// Update Private Profile @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// exports.updatePrivateProfile = function(req, res) {
// }

// Update Password
exports.updatePassword = function(req, res) {
    var updateData = {
        password: req.body.newPasswordInput
    }
    UserModel.update(updateData, {
        where: {
            username: req.session.username
        }
    }).then(function() {
        res.redirect("/profile");
    })
}

// Update Avatar
exports.updateAvatar = function(req, res) {
    var fileName = req.session.username;
    var src;
    var dest;
    var targetPath;
    var tempPath = req.file.path;
    console.log(req.file);
    targetPath = './public/uploads/profileImages/' + fileName;
    src = fs.createReadStream(tempPath);
    dest = fs.createWriteStream(targetPath);
    src.pipe(dest);

    var updateData = {
        profileimg: fileName
    }

    UserModel.update(updateData, {
        where: {
            username: req.session.username
        }
    })

    req.session.picture = fileName;

    fs.unlink(tempPath, function (err) {
        res.redirect("profile");
    });
}

// Terms & Conditions Page
exports.openTermsConditions = function(req, res) {
    res.render("terms&conditions", {
        title: "Terms & Conditions",
        username: req.session.username,
        picture: req.session.picture,
        adminUsername: req.session.adminUsername
    })
}

// Privacy Page
exports.openPrivacy = function(req, res) {
    res.render("privacy", {
        title: "Privacy",
        username: req.session.username,
        picture: req.session.picture,
        adminUsername: req.session.adminUsername
    })
}

// getJSON
    // Check for similar Username
exports.checkSimilarUsername = function(req, res) {
    UserModel.findAll().then(function(allData) {
        var bool;
        for (var i in allData){
            if (req.body.username == allData[i].username){
                bool = false;
                break;
            } else {
                bool = true;
            }
        }
        res.send(bool);
    })
}