var listingModel = require('../models/listingModel');
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

exports.insert = function (req, res) {
    var newListing = {
        fashionGender: req.body.fashionGender,
        category: req.body.category,
        listingTitle: req.body.title,
        itemType: req.body.itemType,
        size: req.body.size,
        material: req.body.material,
        watchMovement: req.body.watchMovement,
        strapType: req.body.strapType,
        dial: req.body.dial,
        brand: req.body.brand,
        price: req.body.price,
        itemCondition: req.body.condition,
        description: req.body.description,
        evidence: req.body.evidence,
        meetup: req.body.meetup,
        delivery: req.body.delivery,
    }
    listingModel.create(newListing).then((newRecord, created) => {
        if (!newRecord) {
            return res.send(400, {
                message: "error"
            });
        }
        res.redirect('/');
    })
};

exports.list = function (req, res) {
    listingModel.findAll({
        attributes: ['listingNo', 'listingTitle', 'price', 'itemType', 'fav', 'username']
    }).then(function (Listings) {
        res.render('categories', {
            title: "Categories",
            itemList: Listings,
            username: req.session.username,
            picture: req.session.picture,
            list: "",
            adminUsername: req.session.adminUsername,
        });
    }).catch((err) => {
        return res.status(400).send ({
            message: err
        });
    });
};

exports.listPopular = function (req, res) {
    sequelizeInstance.query('select * from Listings order by fav desc;', { model:listingModel }).then((Listings) => {
        res.render('categories', {
            title: 'Categories',
            itemList: Listings,
            username: req.session.username,
            picture: req.session.picture,
            list: "Popular",
            adminUsername: req.session.adminUsername,
        });
    })
};

exports.listHighLow = function (req, res) {
    sequelizeInstance.query('select * from Listings order by price desc;', { model:listingModel }).then((Listings) => {
        res.render('categories', {
            title: 'Categories',
            itemList: Listings,
            username: req.session.username,
            picture: req.session.picture,
            list: "HNL",
            adminUsername: req.session.adminUsername,
        });
    })
};

exports.listLowHigh = function (req, res) {
    sequelizeInstance.query('select * from Listings order by price;', { model:listingModel }).then((Listings) => {
        res.render('categories', {
            title: 'Categories',
            itemList: Listings,
            username: req.session.username,
            picture: req.session.picture,
            list: "LNH",
            adminUsername: req.session.adminUsername,
        });
    })
};