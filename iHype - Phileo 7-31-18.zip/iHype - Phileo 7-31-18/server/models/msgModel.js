var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const msgModel = sequelizeInstance.define('Msg', {
    message: {
        type: Sequelize.STRING
    },
    buyer: {
        type: Sequelize.STRING,
    },
    seller: {
        type: Sequelize.STRING,
    },
    productName: {
        type: Sequelize.STRING,
        defaultValue: "This is TEMPORARY until next integration"
    },
});

msgModel.sync({ force: false });

module.exports = sequelizeInstance.model('Msg', msgModel);