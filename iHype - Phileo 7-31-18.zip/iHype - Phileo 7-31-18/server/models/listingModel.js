var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const listingDetails = sequelizeInstance.define('Listings', {
    listingNo: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    listingIMG1: {
        type: Sequelize.STRING,
    },
    fashionGender:{
        type: Sequelize.STRING,
    },
    category: {
        type: Sequelize.STRING,
    },
    listingTitle: {
        type: Sequelize.STRING,
        allowNull: false,
    },
    itemType:{
        type: Sequelize.STRING,
    },
    size: {
        type: Sequelize.STRING,
    },
    material: {
        type: Sequelize.STRING,
    },
    watchMovement:{
        type: Sequelize.STRING,
    },
    strapType: {
        type: Sequelize.STRING,
    },
    dial: {
        type: Sequelize.STRING,
    },
    brand: {
        type: Sequelize.STRING,
        defaultValue: "Not Stated"
    },
    price: {
        type: Sequelize.FLOAT,
        trim: true,
        allowNull: false
    },
    itemCondition: {
        type: Sequelize.STRING,
    },
    description: {
        type: Sequelize.STRING,
        trim: true,
    },
    evidence: {
        type: Sequelize.STRING,
    },
    fav: {
        type: Sequelize.INTEGER,
        defaultValue: 0,
    },
    comments:{
        type: Sequelize.STRING,
    },
    username: {
        type: Sequelize.STRING,
    }
});

listingDetails.sync({ force: false, logging: console.log }).then(() => {
    console.log("Products table synced");
    listingDetails.upsert({
        listingNo: 1,
        listingTitle: "Nike Shoe",
        price: 100,
        itemType: "sock",
        fav: 30,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 2,
        listingTitle: "Asadi Shirt",
        price: 500,
        itemType: "belt",
        fav: 20,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 3,
        listingTitle: "Rolex Watch",
        price: 100000,
        itemType: "belt",
        fav: 10,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 4,
        listingTitle: "Test",
        price: 100000,
        itemType: "belt",
        fav: 90,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 5,
        listingTitle: "sth",
        price: 500,
        itemType: "belt",
        fav: 0,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 6,
        listingTitle: "What this",
        price: 369,
        itemType: "belt",
        fav: 5,
        username: "phileo",
    });
    listingDetails.upsert({
        listingNo: 7,
        listingTitle: "lololol",
        price: 100,
        itemType: "belt",
        fav: 5,
        username: "phileo",
    });
});

module.exports = sequelizeInstance.model('Listings', listingDetails);