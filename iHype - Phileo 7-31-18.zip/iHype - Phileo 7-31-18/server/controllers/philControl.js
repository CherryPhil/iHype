var fs = require('fs');

var ListingModel = require('../models/listingModel');
var CommentModel = require('../models/commentModel');
var UserModel = require('../models/usersModel');
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

exports.openSell = function(req, res) {
    if(req.session.username == undefined){
        res.redirect("/login");
    } else {
        res.render("sell", {
            title: "Sell",
            username: req.session.username,
            picture: req.session.picture,
        })
    }
};

exports.openDisplay = function(req, res) {
    var name = req.params.name;
    var username = req.params.username;
    var listingTitle = name;
    ListingModel.findAll({
        where: {
            listingTitle: listingTitle,
            username: username,
        }
    }).then(function(listingData){
        UserModel.findAll({
            where: {
                username: req.session.username
            },
            attributes: ['favorites']
        }).then(function(userData){
            CommentModel.findAll({
                where: {
                    username: username,
                    titleName: listingTitle,
                }
            }).then(function(commentData){
                var favData = "";
                if (userData != ""){
                    favData = (userData[0].favorites);
                }
                console.log(favData);
                res.render("display", {
                    title: "Display",
                    datas: listingData[0],
                    userFav: favData,
                    username: req.session.username,
                    picture: req.session.picture,
                    adminUsername: req.session.adminUsername,
                    comments: commentData,
                });
            })
        })
    })
};

exports.uploadSell = function(req, res) {
    var newListing = ({
        fashionGender: req.body.fashionGender,
        category: req.body.category,
        listingTitle: req.body.title,
        itemType: req.body.itemType,
        size: req.body.size,
        material: req.body.material,
        watchMovement: req.body.watchMovement,
        strapType: req.body.strapType,
        dial: req.body.dial,
        brand: req.body.brand,
        price: req.body.price,
        itemCondition: req.body.condition,
        description: req.body.description,
        username: req.session.username,
    });
    ListingModel.create(newListing).then(function(listingData){
        var fileName = req.body.title + JSON.stringify(listingData.listingNo);
        var src;
        var dest;
        var targetPath;
        var tempPath = req.file.path;
        targetPath = './public/uploads/listingImages/' + fileName;
        src = fs.createReadStream(tempPath);
        dest = fs.createWriteStream(targetPath);
        src.pipe(dest);
        var newImage = ({
            listingIMG1: fileName,
        });
        ListingModel.update(newImage, {
            where: {
                listingTitle: req.body.title,
                listingNo: listingData.listingNo,
            }
        })
        fs.unlink(tempPath, function (err) {
            res.redirect("/categories");
        });
    });
};

exports.checkTitle = function(req, res) {
    ListingModel.findAll({
        where: {
            username: req.session.username
        }
    }).then(function(myPosts) {
        var bool = true;
        for (var i = 0; i < myPosts.length; i++) {
            if (req.body.titleName == myPosts[i].listingTitle){
                bool = false
            }
        }
        res.send(bool);
    })
}

exports.increaseFav = function(req, res) {
    var titleName = req.body.titleName;
    var itemUser = req.body.itemUser;
    ListingModel.findAll({
        where: {
            listingTitle: titleName,
            username: itemUser
        }
    }).then(function(thisItem){
        var newNum = thisItem[0].fav + 1;
        var newFavData = {
            fav: newNum
        }
        ListingModel.update(newFavData, {
            where: {
                listingTitle: titleName,
                username: itemUser
            }
        })
        UserModel.findAll({
            where: {
                username: req.session.username
            }
        }).then(function(hola){
            var data = JSON.parse(hola[0].favorites);
            data.push(itemUser + "|-|" + titleName);
            console.log(data);
            var dataForFav = {
                favorites: JSON.stringify(data)
            }
            UserModel.update(dataForFav, {
                where: {
                    username: req.session.username
                }
            })
        })
        res.send(JSON.stringify(newNum));
    })
}

exports.decreaseFav = function(req, res) {
    var titleName = req.body.titleName;
    var itemUser = req.body.itemUser;
    ListingModel.findAll({
        where: {
            listingTitle: titleName,
            username: itemUser
        }
    }).then(function(thisItem){
        var newNum = thisItem[0].fav - 1;
        var newFavData = {
            fav: newNum
        }
        ListingModel.update(newFavData, {
            where: {
                listingTitle: titleName,
                username: itemUser
            }
        })

        UserModel.findAll({
            where: {
                username: req.session.username
            }
        }).then(function(hola){
            var data = JSON.parse(hola[0].favorites);
            for (var i in data){
                if (data[i] == itemUser + "|-|" + titleName){
                    data.splice(i, 1);
                }
            }
            console.log(data);
            var dataForFav = {
                favorites: JSON.stringify(data)
            }
            UserModel.update(dataForFav, {
                where: {
                    username: req.session.username
                }
            })
        })
        
        res.send(JSON.stringify(newNum));
    })
}

exports.postComment = function(req, res){
    var newComment = {
        comment: req.body.comment,
        username: req.session.username,
        itemUser: req.body.itemUser,
        titleName: req.body.titleName,
    };
    CommentModel.create(newComment).then(function(){
        res.redirect("back");
    });
}