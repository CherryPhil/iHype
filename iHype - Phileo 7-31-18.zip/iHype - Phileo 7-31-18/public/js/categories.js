function searchFunction() {
  var input, filter, list, i;
  input = document.getElementById("userInput");
  filter = input.value.toUpperCase();
  list = document.getElementsByClassName("productList");
  for (i = 0; i < list.length; i++) {
    prodName = list[i];
    if (prodName) {
      if (prodName.innerHTML.toUpperCase().indexOf(filter) > -1) {
        list[i].style.display = "";
      } else {
        list[i].style.display = "none";
      }
    }       
  }
}

