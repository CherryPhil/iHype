var MsgModel = require("../models/msgModel");
var offerModel = require("../models/offerModel");
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

exports.myChat = function(req, res) {
    if(req.session.username == undefined){
        res.redirect("/login");
    } else {
        MsgModel.findAll().then(function (datas) {
            res.render("chat", {
            title: "Chat",
            username: req.session.username,
            picture: req.session.picture,
            data: datas,
            url: req.protocol + "://" + req.get("host") + req.url,
            })
        })  
    }
};

exports.UploadOffer = function (req, res){
    var Offer = ({
        method: req.body.method,
        meetup_Date: req.body.meetup_Date,
        meetup_Time: req.body.meetup_Time,
        meetup_location: req.body.meetup_location,
        meetup_price: req.body.meetup_price,
        delivery_Date: req.body.delivery_Date,
        delivery_address: req.body.delivery_address,
        delivery_price: req.body.delivery_price,
    });
    offerModel.create(Offer)
    res.redirect("/chat");
};
